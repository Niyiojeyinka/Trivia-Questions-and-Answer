<div class="w3-container w3-center">

<div class="w3-margin w3-serif w3-text w3-large">Affilate Program</div>	
<center>
<div style="max-width: 80%" class="w3-container w3-padding-large w3-center w3-small">
	You get One Bold Live everytime you referred Three friends to Pryper.
	Your Referral Code is
<br><br>

<span class="w3-xlarge w3-text-theme w3-serif"><?=$user_details['username'] ?></span><br><br>
They are to input this code in the referral field During Registration
<br>
</div></center>


</div>