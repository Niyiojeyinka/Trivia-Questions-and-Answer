<div class="w3-container">
<div style="max_width:90%;" class="w3-container">
<span class=""><?php echo $item['title']; ?></span><br>
<div class="">


<?php echo $item['text']; ?>


</div>



</div>

</div>
