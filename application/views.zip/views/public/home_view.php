

<div class='w3-margin'>
<h1 class="w3-text-theme w3-serif">Whats Pryper?</h1>
<div class="w3-container">
<p class="w3-small">Pryper is a Daily Online  Gaming  Quiz Platform that reward you for answering Trivia Quizes for FREE. </p>
</div>
<ul class="w3-large"><b>
  <li>Play</li>
    <li>Enjoy</li>
  <li>Earn</li>
</b>
</ul>
</div>
<center>
<div style="max-width: 80%;" class="w3-serif w3-large">
    <a href="<?php echo site_url('Register'); ?>" class="w3-block w3-theme w3-round-jumbo w3-button w3-hover-white w3-hover-text-teal w3-margin-bottom">Register</a>
    <a href="<?php echo site_url('Login'); ?>" class="w3-block w3-theme w3-round-jumbo w3-button w3-hover-white w3-hover-text-teal w3-margin-bottom">Login</a>
  </div></center>



