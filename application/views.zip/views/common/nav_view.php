<nav class="w3-bar w3-border w3-car w3-light-grey horizontalmenu"  id="mySidebar">

   <a href="<?php echo site_url(); ?>" class="w3-bar-item w3-button">Home</a>
  <a href="<?php echo site_url('users/login'); ?>" class="w3-bar-item w3-button w3-hover-indigo">Login</a>
  <a href="<?php echo site_url('users/register'); ?>" class="w3-bar-item w3-button w3-hover-indigo">Register</a>
  <a href="#" class="w3-bar-item w3-button w3-hover-indigo">Terms & Condition</a>
  <a href="#" class="w3-bar-item w3-button w3-hover-indigo">Privacy & Policy</a>
  <a href="#" onClick='closeMenu()' class="w3-bar-item w3-button w3-hover-indigo">X</a>

</nav>
