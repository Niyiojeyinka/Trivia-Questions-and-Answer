<div class="w3-container w3-center">
	<div class="w3-margin w3-padding">
	Osun State Nigeria
<i class='fa fa-circle w3-margin'></i>olaniyiojeyinka@gmail.com 
<i class='fa fa-circle w3-margin'></i>www.github.com.ng/niyiojeyinka
<i class='fa fa-circle w3-margin'></i>facebook.com/niyiojeyinka
</div>
<hr>
<i class='fa fa-circle w3-margin'></i>High Performance Applications
<i class='fa fa-circle w3-margin'></i>Continuous Improvement<hr>
<span class="w3-large"><b>SOFTWARE DEVELOPER</b></span>
<p >Experence in building both backend and frontend of a  responsive ,scalable ,manageable ,high quality website.Ability to partner with developer(s) and Collaborate.</p>
<hr>
<span class="w3-small"><b>Technical Proficiencies</b></span>
<p>PHP ,HTML ,CSS ,JAVASCRIPT, JAVA, AJAX, JQUERY, MYSQL, ENTRY LEVEL REACT/REACTNATIVE, MVC, CODEIGNITER, GIT/GITHUB</p>
<hr>
<span class="w3-large w3-margin-bottom"><b>SOFTWARE DEVELOPMENT SKILL</b></span>
	<div>
		<div style="padding-left: 240px;" class="w3-half w3-border-right w3-justify">
			-Object Oriented Programming<br>
			-Procedural Programming<br>
            -Web Development 
		</div>
		<div style="padding-left: 240px;" class="w3-half w3-border-right w3-justify">
			-Global Project Management<br>
			-Data Structure & Algorithms<br>
            -Mobile Application Development<br>
           
		</div>
	</div><BR>
<span class="w3-large w3-margin-bottom"><b>EXPERIENCE</b></span><br>
<span>
<i class='fa fa-circle w3-margin w3-small'></i>Developed An AD Network Server that powered Custch.com</span>
<div>
	<i class='fa fa-angle-right w3-margin w3-small'></i>This involved building a dynmic form builder which powered the CPA Section<br>
    <i class='fa fa-angle-right w3-margin w3-small'></i>Got Litle Experience in API Development when building the Integration section <br>
    <i class='fa fa-angle-right w3-margin w3-small'></i>Got Experience in building Multi-Currency/Country Supported Software <br>

</div>
<br>
<span>
<i class='fa fa-circle w3-margin w3-small'></i>Developed Software that powered Gettew.com;A website builder for High Schools</span>
<div>
    <i class='fa fa-angle-right w3-margin w3-small'></i>Learnt a lot on Software Extensibilty and Plugability<br>
    <i class='fa fa-angle-right w3-margin w3-small'></i>Got Experience in building Extensible,customizable Software<br>
    <i class='fa fa-angle-right w3-margin w3-small'></i>Also Learnt a lot on Building Content Management Software<br>
    <i class='fa fa-angle-right w3-margin w3-small'></i>Have completed more than nine major Projects from CBT Software to price comparison Site.
</div>
<hr>

<hr>

</div>