<body style="max-width:600px"  class="w3-animate-zoom">
<header class="w3-bar w3-card w3-theme w3-cell-row w3-text-white">
    
    <a href="<?= site_url() ?>"><img  style='height:30px;margin-top:32px;margin-bottom:32px;display: inline' class='w3-margin-left w3-left w3-image'
      src='<?php echo base_url('assets/images/pryperwhite.png'); ?>'
       alt='Pryper'/></a>


           </div>

</header>
.