<body style="max-width:1000px"  class="w3-animate-zoom">
<header class="w3-bar w3-card w3-theme w3-cell-row w3-text-white">
    <a class="w3-bar-item w3-button w3-xxlarge w3-margin w3-cell w3-left"
     onclick="openSidebar()"><i  style='margin-right:3%' class="fa fa-bars w3-text-white"></i>
   </a>
    <a href="<?= site_url() ?>"><img  style='height:30px;margin-top:32px;margin-bottom:32px;display: inline' class='w3-margin-right w3-right w3-image'
      src='<?php echo base_url('assets/images/pryperwhite.png'); ?>'
       alt='Pryper'/></a>


           </div>

</header>
