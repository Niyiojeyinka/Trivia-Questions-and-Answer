<div>
	
	<img class="w3-image" src="<?= site_url('dashboard/turn_image') ?>" />
	<?= strlen('Hello World in java is like how 
many Let the browser know that it is an PNG image?lines of code just to make look very longer for efficiency confirmation.ok lets ride on and lets pray at this point that Almigthy God the Supreme one lets this project succeed Amen.')?>
</div>