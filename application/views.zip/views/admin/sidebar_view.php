<div class="w3-third w3-white">
<div id="menuc" class="w3-text-white w3-black">
<a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/");?>">Go to Home</a><br>
    <br>
    <a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin");?>">Admin Home</a><br><br>

    <a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin/our_users");?>">Users</a><br><br>

<a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin_blog/pages/no");?>">Pages</a><br><br>

<a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin_blog/add_page");?>">Create New Pages</a><br><br>

<a class="w3-text-white w3-padding w3-hover-white"  href="<?php echo site_url("/admin_blog/draft");?>">Drafts</a><br><br>

<a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin_blog/board_posts");?>">Board Posts</a><br><br>

<a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin_blog/admin_board_posts");?>">Admin Board Posts</a><br><br>
<a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin_blog/add_board_post");?>">Add Board Post</a><br><br>

<a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin_question/add_question");?>">Add New Question</a><br><br>
<!-- later on scale change to admistrative country -->
<a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin_question/questions/nigeria");?>">Questions</a><br><br>

<a class="w3-text-white w3-padding w3-hover-white"  href="<?php echo site_url("/admin/manage_tips");?>">Manage Tips</a><br><br>

<a class="w3-text-white w3-padding w3-hover-white"  href="<?php echo site_url("/admin/set_game_time");?>">Set Game Time</a><br><br>

<a class="w3-text-white w3-padding w3-hover-white"  href="<?php echo site_url("/admin/set_voting_time");?>">Set Voting Time</a><br><br>

 <a class="w3-text-white w3-padding w3-hover-white"  href="<?php echo site_url("/admin/add_common");?>">Add Common Content</a><br><br>

 <a class="w3-text-white w3-padding w3-hover-white"  href="<?php echo site_url("/admin/withdrawal
");?>">Withdrawals</a><br><br>

 <a class="w3-text-white w3-padding w3-hover-white"  href="<?php echo site_url("/admin/winners");?>">Winners</a><br><br>

 

   <a class="w3-text-white w3-padding w3-hover-white"  href="<?php echo site_url("/admin/view_tip_vote_result");?>">View Vote Result</a><br><br>



   <a class="w3-text-white w3-padding w3-hover-white"  href="<?php echo site_url("/admin/send_sms");?>">Send SMS</a><br><br>



</div>
</div>
